﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Constants {
    public const string PLAYER_TAG = "Player";
    public const int MAX_ITEM_STACK_SIZE = 16;
}
