﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu (fileName ="New Repairable", menuName ="Items/Repairable")]
public class Repairable : Item
{
    
    public override void Use()
    {
        base.Use();
    }
}
